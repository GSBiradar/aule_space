#include <iostream>
#include "modules/dynamics.h"

int main() {
    SpacecraftDynamics dynamics;

    SpacecraftDynamics::Config config;
    config.mass = 100.0;
    config.inertia << 10, 0, 0,
                      0, 10, 0,
                      0, 0, 5;
    config.wheel_inertia = 0.01;
    config.max_wheel_speed = 1000;
    config.max_wheel_torque = 0.1;
    config.wheel_matrix <<
        0.577,  0.577, -0.577, -0.577,
        0.577, -0.577,  0.577, -0.577,
        0.577, -0.577, -0.577,  0.577;

    dynamics.initialize(config);

    AttitudeState state;
    ControlCommand cmd;
    cmd.wheel_torques << 0.01, -0.01, 0.01, -0.01;

    for (int i = 0; i < 100; ++i) {
        dynamics.update(0.01, cmd, state);
        std::cout << "ω = " << state.angular_velocity.transpose() << std::endl;
    }

    return 0;
}
