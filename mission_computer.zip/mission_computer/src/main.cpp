#include <iostream>
#include <memory>
#include <signal.h>
#include <atomic>
#include "core/scheduler.h"
#include "core/ipc.h"
#include "modules/controller.h"
#include "modules/dynamics.h"
#include "modules/actuator.h"
#include "modules/sensor.h"
#include "config/config_manager.h"

std::atomic<bool> running(true);

void signal_handler(int signal) {
    std::cout << "Received signal " << signal << ", shutting down..." << std::endl;
    running = false;
}

int main(int argc, char* argv[]) {
    // Setup signal handling
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    std::cout << "=== Mission Computer Simulation ===" << std::endl;
    std::cout << "Loading configuration..." << std::endl;
    
    // Load configuration
    ConfigManager config_manager;
    std::string config_file = "config/simulation.yaml";
    
    if (argc > 1) {
        config_file = argv[1];
    }
    
    if (!config_manager.load_config(config_file)) {
        std::cerr << "Failed to load configuration from " << config_file << std::endl;
        std::cout << "Using default configuration..." << std::endl;
        config_manager.set_default_config();
    }
    
    auto config = config_manager.get_config();
    
    // Initialize modules
    std::cout << "Initializing modules..." << std::endl;
    
    auto ipc_manager = std::make_shared<IPCManager>();
    auto scheduler = std::make_unique<Scheduler>();
    
    LQRController controller;
    SpacecraftDynamics dynamics;
    ReactionWheelActuator actuator;
    AttitudeSensor sensor;
    
    controller.initialize(config.controller_config);
    dynamics.initialize(config.dynamics_config);
    actuator.initialize(config.actuator_config);
    sensor.initialize(config.sensor_config);
    
    // Set initial state
    AttitudeState initial_state;
    initial_state.attitude = config.initial_conditions.attitude;
    initial_state.angular_velocity = config.initial_conditions.angular_velocity;
    initial_state.wheel_speeds = config.initial_conditions.wheel_speeds;
    initial_state.timestamp = 0;
    
    ipc_manager->publish_attitude_state(initial_state);
    
    // Set reference attitude (pointing at target)
    Eigen::Quaterniond reference_attitude(1.0, 0.0, 0.0, 0.0);  // Identity
    controller.set_reference_attitude(reference_attitude);
    
    // Task functions
    auto controller_task = [&]() {
        AttitudeState current_state;
        SensorData sensor_data;
        
        if (ipc_manager->get_latest_attitude_state(current_state) &&
            ipc_manager->get_latest_sensor_data(sensor_data)) {
            
            auto cmd = controller.compute_control(reference_attitude,
                                                 sensor_data,
                                                 current_state);
            cmd.timestamp = static_cast<uint64_t>(scheduler->get_simulation_time() * 1e6);
            ipc_manager->publish_control_command(cmd);
            ipc_manager->log_control(cmd);
        }
    };
    
    auto dynamics_task = [&]() {
        ControlCommand cmd;
        AttitudeState state;
        
        if (ipc_manager->get_latest_attitude_state(state) &&
            ipc_manager->get_latest_control_command(cmd)) {
            
            dynamics.update(0.01, cmd, state);  // 100 Hz -> dt = 0.01
            state.timestamp = static_cast<uint64_t>(scheduler->get_simulation_time() * 1e6);
            
            ipc_manager->publish_attitude_state(state);
            ipc_manager->log_state(state);
        }
    };
    
    auto actuator_task = [&]() {
        ControlCommand cmd;
        if (ipc_manager->get_latest_control_command(cmd)) {
            // Apply actuator dynamics
            AttitudeState state;
            if (ipc_manager->get_latest_attitude_state(state)) {
                actuator.update_dynamics(0.05, cmd.wheel_torques, state.wheel_speeds);  // 20 Hz
                actuator.apply_saturation(cmd.wheel_torques, state.wheel_speeds);
                
                // Update state with new wheel speeds
                state.timestamp = static_cast<uint64_t>(scheduler->get_simulation_time() * 1e6);
                ipc_manager->publish_attitude_state(state);
            }
        }
    };
    
    auto sensor_task = [&]() {
        AttitudeState true_state;
        if (ipc_manager->get_latest_attitude_state(true_state)) {
            auto measurement = sensor.generate_measurement(true_state,
                                                         static_cast<uint64_t>(
                                                             scheduler->get_simulation_time() * 1e6));
            ipc_manager->publish_sensor_data(measurement);
        }
    };
    
    // Add tasks to scheduler
    scheduler->add_task("Controller", 20, controller_task, 2);   // 50 Hz
    scheduler->add_task("Dynamics", 10, dynamics_task, 1);      // 100 Hz
    scheduler->add_task("Actuator", 50, actuator_task, 3);      // 20 Hz
    scheduler->add_task("Sensor", 100, sensor_task, 4);         // 10 Hz
    
    std::cout << "Starting simulation..." << std::endl;
    std::cout << "Duration: " << config.simulation_params.duration << " seconds" << std::endl;
    
    // Run simulation
    scheduler->run_simulation(config.simulation_params.duration);
    
    // Save logs
    std::cout << "Saving logs..." << std::endl;
    ipc_manager->save_logs_to_file(config.simulation_params.log_file);
    
    std::cout << "Simulation completed successfully!" << std::endl;
    
    return 0;
}