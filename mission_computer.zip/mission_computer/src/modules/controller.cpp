#include "modules/controller.h"
#include <iostream>
#include <cmath>

LQRController::LQRController() {
    // Default configuration
    config_.Q = Eigen::Matrix<double, 6, 6>::Identity();
    config_.R = Eigen::Matrix<double, 3, 3>::Identity();
    config_.K = Eigen::Matrix<double, 3, 6>::Zero();
    config_.max_torque = 0.1;
    config_.integral_gain = 0.0;
    
    reference_attitude_ = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
    integral_error_ = Eigen::Vector3d::Zero();
}

void LQRController::initialize(const Config& config) {
    config_ = config;
    std::cout << "LQR Controller initialized with max torque: " 
              << config_.max_torque << " N·m" << std::endl;
}

ControlCommand LQRController::compute_control(const Eigen::Quaterniond& q_ref,
                                             const SensorData& sensor_data,
                                             const AttitudeState& state) {
    ControlCommand cmd;
    
    // Compute quaternion error
    Eigen::Vector3d q_error = compute_quaternion_error(q_ref, sensor_data.measured_attitude);
    
    // State vector: [q_error, angular_rates]
    Eigen::Matrix<double, 6, 1> x;
    x << q_error, sensor_data.measured_rates;
    
    // Compute control torque using LQR
    Eigen::Vector3d torque_body = -config_.K * x;
    
    // Add integral action if configured
    if (config_.integral_gain > 0) {
        integral_error_ += q_error * 0.01;  // dt = 0.01 for 100 Hz
        torque_body += config_.integral_gain * integral_error_;
    }
    
    // Apply torque limits
    double torque_norm = torque_body.norm();
    if (torque_norm > config_.max_torque) {
        torque_body = torque_body * (config_.max_torque / torque_norm);
    }
    
    // Allocate torque to reaction wheels
    cmd.torque_body = torque_body;
    cmd.wheel_torques = torque_allocation(torque_body);
    cmd.timestamp = sensor_data.timestamp;
    
    return cmd;
}

void LQRController::set_reference_attitude(const Eigen::Quaterniond& q_ref) {
    reference_attitude_ = q_ref;
    integral_error_.setZero();  // Reset integral error when reference changes
}

Eigen::Vector3d LQRController::compute_quaternion_error(const Eigen::Quaterniond& q_ref,
                                                       const Eigen::Quaterniond& q_est) {
    // Compute error quaternion: q_error = q_ref^-1 * q_est
    Eigen::Quaterniond q_error = q_ref.conjugate() * q_est;
    
    // Ensure positive scalar part for shortest path
    if (q_error.w() < 0) {
        q_error.coeffs() = -q_error.coeffs();
    }
    
    // Convert to vector part for small errors (approximation)
    // For larger errors, use: error = 2 * atan2(|v|, w) * v/|v|
    double angle = 2.0 * std::acos(std::min(1.0, std::abs(q_error.w())));
    
    if (angle < 1e-6) {
        return Eigen::Vector3d::Zero();
    }
    
    Eigen::Vector3d axis = q_error.vec().normalized();
    return axis * angle;
}

Eigen::Vector4d LQRController::torque_allocation(const Eigen::Vector3d& torque_body) {
    // Simple allocation matrix for 4 reaction wheels in tetrahedral configuration
    Eigen::Matrix<double, 4, 3> A;
    A <<  1,  1,  1,
          1, -1, -1,
         -1,  1, -1,
         -1, -1,  1;
    
    A = A / std::sqrt(3.0);
    
    // Solve: min ||w||^2 subject to A*w = torque_body
    // Using pseudo-inverse: w = A^T * (A*A^T)^-1 * torque_body
    Eigen::Matrix3d AAT = A * A.transpose();
    Eigen::Vector4d wheel_torques = A.transpose() * AAT.inverse() * torque_body;
    
    return wheel_torques;
}

bool LQRController::compute_lqr_gain(const Eigen::Matrix<double, 6, 6>& A,
                                    const Eigen::Matrix<double, 6, 3>& B,
                                    const Eigen::Matrix<double, 6, 6>& Q,
                                    const Eigen::Matrix<double, 3, 3>& R) {
    // Note: In practice, use a proper LQR solver like care() from control systems library
    // This is a placeholder implementation
    
    // For spacecraft attitude control, we often pre-compute gains
    // Here we'll just set some reasonable default gains
    
    config_.K << 10.0, 0.0, 0.0, 5.0, 0.0, 0.0,
                 0.0, 10.0, 0.0, 0.0, 5.0, 0.0,
                 0.0, 0.0, 10.0, 0.0, 0.0, 5.0;
    
    return true;
}