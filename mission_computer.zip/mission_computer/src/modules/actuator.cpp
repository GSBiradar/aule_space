#include "modules/actuator.h"
#include <iostream>
#include <algorithm>

ReactionWheelActuator::ReactionWheelActuator() {
    // Default configuration
    config_.max_torque = 0.1;      // N·m
    config_.max_speed = 6000.0 * M_PI / 30.0;  // rad/s
    config_.friction_coefficient = 0.001;
    config_.motor_constant = 0.05;  // N·m/A
    config_.resistance = 1.0;       // Ohms
    config_.time_constant = 0.01;   // seconds
    
    // Tetrahedral configuration
    config_.allocation_matrix <<  1,  1, -1, -1,
                                  1, -1,  1, -1,
                                  1, -1, -1,  1;
    config_.allocation_matrix /= std::sqrt(3.0);
    
    previous_torques_ = Eigen::Vector4d::Zero();
}

void ReactionWheelActuator::initialize(const Config& config) {
    config_ = config;
    previous_torques_ = Eigen::Vector4d::Zero();
    
    std::cout << "Reaction Wheel Actuator initialized" << std::endl;
    std::cout << "Max torque: " << config_.max_torque << " N·m" << std::endl;
    std::cout << "Max speed: " << config_.max_speed << " rad/s" << std::endl;
}

Eigen::Vector4d ReactionWheelActuator::compute_wheel_torques(const Eigen::Vector3d& torque_body) {
    // Use pseudo-inverse allocation
    Eigen::Matrix<double, 4, 3> A = config_.allocation_matrix.transpose();
    Eigen::Matrix3d AAT = config_.allocation_matrix * A;
    
    Eigen::Vector4d wheel_torques = A * AAT.inverse() * torque_body;
    
    return wheel_torques;
}

void ReactionWheelActuator::apply_saturation(Eigen::Vector4d& wheel_torques,
                                            Eigen::Vector4d& wheel_speeds) {
    for (int i = 0; i < 4; ++i) {
        // Torque saturation
        if (wheel_torques[i] > config_.max_torque) {
            wheel_torques[i] = config_.max_torque;
        } else if (wheel_torques[i] < -config_.max_torque) {
            wheel_torques[i] = -config_.max_torque;
        }
        
        // Speed saturation (with torque reduction near limits)
        if (wheel_speeds[i] > config_.max_speed * 0.9) {
            // Reduce torque when approaching max speed
            wheel_torques[i] = std::min(wheel_torques[i], 0.0);
        } else if (wheel_speeds[i] < -config_.max_speed * 0.9) {
            wheel_torques[i] = std::max(wheel_torques[i], 0.0);
        }
    }
}

void ReactionWheelActuator::update_dynamics(double dt, Eigen::Vector4d& wheel_torques,
                                           Eigen::Vector4d& wheel_speeds) {
    if (dt <= 0.0) {
        return;
    }
    
    // Simulate first-order lag in torque response
    double alpha = dt / (config_.time_constant + dt);
    
    for (int i = 0; i < 4; ++i) {
        // Low-pass filter on torque commands
        wheel_torques[i] = alpha * wheel_torques[i] + 
                          (1.0 - alpha) * previous_torques_[i];
        
        // Update wheel speeds based on torque
        double acceleration = wheel_torques[i] / 0.01;  // Assuming 0.01 kg·m² wheel inertia
        wheel_speeds[i] += acceleration * dt;
        
        // Apply friction
        double friction_torque = config_.friction_coefficient * wheel_speeds[i];
        wheel_speeds[i] -= friction_torque * dt / 0.01;
        
        previous_torques_[i] = wheel_torques[i];
    }
}