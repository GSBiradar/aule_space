#include "modules/dynamics.h"
#include <iostream>

SpacecraftDynamics::SpacecraftDynamics() {
    // Default configuration
    config_.mass = 100.0;  // kg
    config_.inertia << 10.0, 0.0, 0.0,
                       0.0, 10.0, 0.0,
                       0.0, 0.0, 5.0;  // kg·m²
    config_.inertia_inv = config_.inertia.inverse();
    config_.wheel_inertia = 0.01;  // kg·m²
    config_.max_wheel_speed = 6000.0 * M_PI / 30.0;  // rad/s (6000 RPM)
    config_.max_wheel_torque = 0.1;  // N·m
    
    // Tetrahedral reaction wheel configuration
    config_.wheel_matrix <<  1,  1, -1, -1,
                             1, -1,  1, -1,
                             1, -1, -1,  1;
    config_.wheel_matrix /= std::sqrt(3.0);
}

void SpacecraftDynamics::initialize(const Config& config) {
    config_ = config;
    config_.inertia_inv = config_.inertia.inverse();
    
    std::cout << "Spacecraft Dynamics initialized" << std::endl;
    std::cout << "Mass: " << config_.mass << " kg" << std::endl;
    std::cout << "Inertia: \n" << config_.inertia << std::endl;
}

void SpacecraftDynamics::update(double dt, const ControlCommand& cmd, AttitudeState& state) {
    if (dt <= 0.0) {
        return;
    }
    
    // Compute total torque (external + reaction wheels)
    Eigen::Vector3d total_torque = compute_total_torque(cmd, state);
    
    // Update angular velocity
    update_angular_velocity(dt, total_torque, state);
    
    // Update attitude
    update_attitude(dt, state);
    
    // Update reaction wheels
    update_reaction_wheels(dt, cmd, state);
}

Eigen::Matrix3d SpacecraftDynamics::compute_skew_symmetric(const Eigen::Vector3d& v) {
    Eigen::Matrix3d S;
    S << 0.0, -v.z(), v.y(),
         v.z(), 0.0, -v.x(),
        -v.y(), v.x(), 0.0;
    return S;
}

void SpacecraftDynamics::quaternion_derivative(Eigen::Quaterniond& q, 
                                              const Eigen::Vector3d& omega) {
    Eigen::Quaterniond dq;
    dq.w() = -0.5 * (q.x() * omega.x() + q.y() * omega.y() + q.z() * omega.z());
    dq.x() =  0.5 * (q.w() * omega.x() + q.z() * omega.y() - q.y() * omega.z());
    dq.y() =  0.5 * (-q.z() * omega.x() + q.w() * omega.y() + q.x() * omega.z());
    dq.z() =  0.5 * (q.y() * omega.x() - q.x() * omega.y() + q.w() * omega.z());
    
    q.coeffs() += dq.coeffs();
    q.normalize();
}

Eigen::Vector3d SpacecraftDynamics::compute_total_torque(const ControlCommand& cmd,
                                                        const AttitudeState& state) {
    // Total torque = reaction wheel torque - wheel gyroscopic torque
    Eigen::Vector3d wheel_torque_body = config_.wheel_matrix * cmd.wheel_torques;
    
    // Gyroscopic torque from reaction wheels
    Eigen::Vector3d gyroscopic_torque = Eigen::Vector3d::Zero();
    for (int i = 0; i < 4; ++i) {
        Eigen::Vector3d wheel_axis = config_.wheel_matrix.col(i);
        gyroscopic_torque += config_.wheel_inertia * state.wheel_speeds[i] *
                            state.angular_velocity.cross(wheel_axis);
    }
    
    return wheel_torque_body - gyroscopic_torque;
}

void SpacecraftDynamics::update_attitude(double dt, AttitudeState& state) {
    // Use quaternion integration
    Eigen::Vector3d omega = state.angular_velocity;
    
    // Exact solution for constant angular velocity
    double omega_norm = omega.norm();
    if (omega_norm > 1e-6) {
        Eigen::Vector3d omega_unit = omega / omega_norm;
        double angle = omega_norm * dt;
        
        Eigen::Quaterniond delta_q;
        delta_q.w() = std::cos(angle / 2.0);
        delta_q.vec() = std::sin(angle / 2.0) * omega_unit;
        
        state.attitude = state.attitude * delta_q;
        state.attitude.normalize();
    }
}

void SpacecraftDynamics::update_angular_velocity(double dt, const Eigen::Vector3d& torque,
                                                AttitudeState& state) {
    // Euler's rotation equation: I·ω̇ + ω × (I·ω) = τ
    Eigen::Vector3d angular_momentum = config_.inertia * state.angular_velocity;
    
    // Add reaction wheel angular momentum
    for (int i = 0; i < 4; ++i) {
        angular_momentum += config_.wheel_inertia * state.wheel_speeds[i] *
                           config_.wheel_matrix.col(i);
    }
    
    // Compute angular acceleration
    Eigen::Vector3d angular_acceleration = config_.inertia_inv *
        (torque - state.angular_velocity.cross(angular_momentum));
    
    // Integrate using forward Euler (for simplicity)
    state.angular_velocity += angular_acceleration * dt;
}

void SpacecraftDynamics::update_reaction_wheels(double dt, const ControlCommand& cmd,
                                               AttitudeState& state) {
    // Simple first-order reaction wheel dynamics
    for (int i = 0; i < 4; ++i) {
        // Wheel acceleration from torque
        double wheel_acceleration = cmd.wheel_torques[i] / config_.wheel_inertia;
        state.wheel_speeds[i] += wheel_acceleration * dt;
        
        // Apply speed limits
        if (state.wheel_speeds[i] > config_.max_wheel_speed) {
            state.wheel_speeds[i] = config_.max_wheel_speed;
        } else if (state.wheel_speeds[i] < -config_.max_wheel_speed) {
            state.wheel_speeds[i] = -config_.max_wheel_speed;
        }
        
        // Store applied torques
        state.wheel_torques[i] = cmd.wheel_torques[i];
    }
}