#include "modules/sensor.h"
#include <iostream>
#include <cmath>
#include <chrono>

AttitudeSensor::AttitudeSensor() : random_engine_(std::random_device{}()),
                                   normal_dist_(0.0, 1.0) {
    // Default configuration
    config_.attitude_noise_std = 0.01 * M_PI / 180.0;  // 0.01 deg to rad
    config_.rate_noise_std = 0.01 * M_PI / 180.0;      // 0.01 deg/s to rad/s
    config_.wheel_speed_noise_std = 0.001;             // rad/s
    config_.update_rate_hz = 10.0;
    config_.latency = 0.0;
    config_.enable_noise = true;
    
    last_update_time_ = 0.0;
}

void AttitudeSensor::initialize(const Config& config) {
    config_ = config;
    last_update_time_ = 0.0;
    
    std::cout << "Attitude Sensor initialized" << std::endl;
    std::cout << "Update rate: " << config_.update_rate_hz << " Hz" << std::endl;
    std::cout << "Attitude noise: " << config_.attitude_noise_std * 180.0 / M_PI 
              << " deg (1σ)" << std::endl;
}

SensorData AttitudeSensor::generate_measurement(const AttitudeState& true_state,
                                               uint64_t timestamp) {
    SensorData measurement;
    
    // Check if it's time to update based on rate
    double current_time = timestamp * 1e-6;  // Convert to seconds
    if (current_time - last_update_time_ < 1.0 / config_.update_rate_hz) {
        measurement.valid = false;
        return measurement;
    }
    
    last_update_time_ = current_time;
    
    // Add noise to measurements
    if (config_.enable_noise) {
        measurement.measured_attitude = add_attitude_noise(true_state.attitude);
        measurement.measured_rates = add_rate_noise(true_state.angular_velocity);
        measurement.measured_wheel_speeds = add_wheel_noise(true_state.wheel_speeds);
    } else {
        measurement.measured_attitude = true_state.attitude;
        measurement.measured_rates = true_state.angular_velocity;
        measurement.measured_wheel_speeds = true_state.wheel_speeds;
    }
    
    measurement.timestamp = timestamp;
    measurement.valid = true;
    
    return measurement;
}

Eigen::Quaterniond AttitudeSensor::add_attitude_noise(const Eigen::Quaterniond& true_attitude) {
    if (!config_.enable_noise || config_.attitude_noise_std < 1e-12) {
        return true_attitude;
    }
    
    // Generate small rotation noise
    Eigen::Vector3d noise_vec;
    for (int i = 0; i < 3; ++i) {
        noise_vec[i] = normal_dist_(random_engine_) * config_.attitude_noise_std;
    }
    
    double noise_angle = noise_vec.norm();
    if (noise_angle < 1e-12) {
        return true_attitude;
    }
    
    Eigen::Vector3d noise_axis = noise_vec / noise_angle;
    Eigen::Quaterniond noise_quat;
    noise_quat.w() = std::cos(noise_angle / 2.0);
    noise_quat.vec() = std::sin(noise_angle / 2.0) * noise_axis;
    
    // Apply noise: measured = true * noise
    Eigen::Quaterniond measured = true_attitude * noise_quat;
    measured.normalize();
    
    return measured;
}

Eigen::Vector3d AttitudeSensor::add_rate_noise(const Eigen::Vector3d& true_rates) {
    if (!config_.enable_noise || config_.rate_noise_std < 1e-12) {
        return true_rates;
    }
    
    Eigen::Vector3d noisy_rates = true_rates;
    for (int i = 0; i < 3; ++i) {
        noisy_rates[i] += normal_dist_(random_engine_) * config_.rate_noise_std;
    }
    
    return noisy_rates;
}

Eigen::Vector4d AttitudeSensor::add_wheel_noise(const Eigen::Vector4d& true_speeds) {
    if (!config_.enable_noise || config_.wheel_speed_noise_std < 1e-12) {
        return true_speeds;
    }
    
    Eigen::Vector4d noisy_speeds = true_speeds;
    for (int i = 0; i < 4; ++i) {
        noisy_speeds[i] += normal_dist_(random_engine_) * config_.wheel_speed_noise_std;
    }
    
    return noisy_speeds;
}