#include "config/config_manager.h"
#include <iostream>
#include <fstream>

ConfigManager::ConfigManager() {
    set_default_config();
}

bool ConfigManager::load_config(const std::string& config_file) {
    try {
        YAML::Node config = YAML::LoadFile(config_file);
        
        // Load initial conditions
        if (config["initial_conditions"]) {
            auto ic = config["initial_conditions"];
            config_.initial_conditions.attitude = parse_quaternion(ic["attitude"]);
            config_.initial_conditions.angular_velocity = parse_vector3d(ic["angular_velocity"]);
            config_.initial_conditions.wheel_speeds = parse_vector4d(ic["wheel_speeds"]);
        }
        
        // Load simulation parameters
        if (config["simulation"]) {
            auto sim = config["simulation"];
            config_.simulation_params.duration = sim["duration"].as<double>();
            config_.simulation_params.time_step = sim["time_step"].as<double>();
            config_.simulation_params.real_time = sim["real_time"].as<bool>();
            config_.simulation_params.real_time_factor = sim["real_time_factor"].as<double>();
            config_.simulation_params.log_file = sim["log_file"].as<std::string>();
        }
        
        // Load controller config
        if (config["controller"]) {
            auto ctrl = config["controller"];
            config_.controller_config.Q = parse_matrix6d(ctrl["Q"]);
            config_.controller_config.R = parse_matrix3x3(ctrl["R"]);
            config_.controller_config.K = parse_matrix3x6(ctrl["K"]);
            config_.controller_config.max_torque = ctrl["max_torque"].as<double>();
            config_.controller_config.integral_gain = ctrl["integral_gain"].as<double>();
        }
        
        // Load dynamics config
        if (config["dynamics"]) {
            auto dyn = config["dynamics"];
            config_.dynamics_config.mass = dyn["mass"].as<double>();
            config_.dynamics_config.inertia = parse_matrix3d(dyn["inertia"]);
            config_.dynamics_config.wheel_inertia = dyn["wheel_inertia"].as<double>();
            config_.dynamics_config.max_wheel_speed = dyn["max_wheel_speed"].as<double>();
            config_.dynamics_config.max_wheel_torque = dyn["max_wheel_torque"].as<double>();
            config_.dynamics_config.wheel_matrix = parse_matrix3x4(dyn["wheel_matrix"]);
        }
        
        // Load actuator config
        if (config["actuator"]) {
            auto act = config["actuator"];
            config_.actuator_config.max_torque = act["max_torque"].as<double>();
            config_.actuator_config.max_speed = act["max_speed"].as<double>();
            config_.actuator_config.friction_coefficient = act["friction_coefficient"].as<double>();
            config_.actuator_config.motor_constant = act["motor_constant"].as<double>();
            config_.actuator_config.resistance = act["resistance"].as<double>();
            config_.actuator_config.time_constant = act["time_constant"].as<double>();
            config_.actuator_config.allocation_matrix = parse_matrix3x4(act["allocation_matrix"]);
        }
        
        // Load sensor config
        if (config["sensor"]) {
            auto sens = config["sensor"];
            config_.sensor_config.attitude_noise_std = sens["attitude_noise_std"].as<double>();
            config_.sensor_config.rate_noise_std = sens["rate_noise_std"].as<double>();
            config_.sensor_config.wheel_speed_noise_std = sens["wheel_speed_noise_std"].as<double>();
            config_.sensor_config.update_rate_hz = sens["update_rate_hz"].as<double>();
            config_.sensor_config.latency = sens["latency"].as<double>();
            config_.sensor_config.enable_noise = sens["enable_noise"].as<bool>();
        }
        
        std::cout << "Configuration loaded from " << config_file << std::endl;
        return true;
        
    } catch (const YAML::Exception& e) {
        std::cerr << "Error loading configuration: " << e.what() << std::endl;
        return false;
    }
}

void ConfigManager::set_default_config() {
    // Set default values
    config_.initial_conditions.attitude = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
    config_.initial_conditions.angular_velocity = Eigen::Vector3d(0.01, 0.0, 0.0);
    config_.initial_conditions.wheel_speeds = Eigen::Vector4d::Zero();
    
    config_.simulation_params.duration = 10.0;
    config_.simulation_params.time_step = 0.001;
    config_.simulation_params.real_time = false;
    config_.simulation_params.real_time_factor = 1.0;
    config_.simulation_params.log_file = "simulation_log.csv";
    
    // Controller defaults
    config_.controller_config.Q = Eigen::Matrix<double, 6, 6>::Identity();
    config_.controller_config.R = Eigen::Matrix<double, 3, 3>::Identity();
    config_.controller_config.K << 10.0, 0.0, 0.0, 5.0, 0.0, 0.0,
                                   0.0, 10.0, 0.0, 0.0, 5.0, 0.0,
                                   0.0, 0.0, 10.0, 0.0, 0.0, 5.0;
    config_.controller_config.max_torque = 0.1;
    config_.controller_config.integral_gain = 0.0;
    
    // Dynamics defaults
    config_.dynamics_config.mass = 100.0;
    config_.dynamics_config.inertia << 10.0, 0.0, 0.0,
                                       0.0, 10.0, 0.0,
                                       0.0, 0.0, 5.0;
    config_.dynamics_config.wheel_inertia = 0.01;
    config_.dynamics_config.max_wheel_speed = 6000.0 * M_PI / 30.0;
    config_.dynamics_config.max_wheel_torque = 0.1;
    config_.dynamics_config.wheel_matrix <<  1,  1, -1, -1,
                                             1, -1,  1, -1,
                                             1, -1, -1,  1;
    config_.dynamics_config.wheel_matrix /= std::sqrt(3.0);
    
    // Actuator defaults
    config_.actuator_config.max_torque = 0.1;
    config_.actuator_config.max_speed = 6000.0 * M_PI / 30.0;
    config_.actuator_config.friction_coefficient = 0.001;
    config_.actuator_config.motor_constant = 0.05;
    config_.actuator_config.resistance = 1.0;
    config_.actuator_config.time_constant = 0.01;
    config_.actuator_config.allocation_matrix = config_.dynamics_config.wheel_matrix;
    
    // Sensor defaults
    config_.sensor_config.attitude_noise_std = 0.01 * M_PI / 180.0;
    config_.sensor_config.rate_noise_std = 0.01 * M_PI / 180.0;
    config_.sensor_config.wheel_speed_noise_std = 0.001;
    config_.sensor_config.update_rate_hz = 10.0;
    config_.sensor_config.latency = 0.0;
    config_.sensor_config.enable_noise = true;
    
    std::cout << "Using default configuration" << std::endl;
}

const SimulationConfig& ConfigManager::get_config() const {
    return config_;
}

void ConfigManager::save_config(const std::string& config_file) const {
    YAML::Emitter out;
    out << YAML::BeginMap;
    
    // Save initial conditions
    out << YAML::Key << "initial_conditions" << YAML::Value << YAML::BeginMap;
    out << YAML::Key << "attitude" << YAML::Flow << YAML::BeginSeq
        << config_.initial_conditions.attitude.w()
        << config_.initial_conditions.attitude.x()
        << config_.initial_conditions.attitude.y()
        << config_.initial_conditions.attitude.z() << YAML::EndSeq;
    out << YAML::Key << "angular_velocity" << YAML::Flow << YAML::BeginSeq
        << config_.initial_conditions.angular_velocity[0]
        << config_.initial_conditions.angular_velocity[1]
        << config_.initial_conditions.angular_velocity[2] << YAML::EndSeq;
    out << YAML::Key << "wheel_speeds" << YAML::Flow << YAML::BeginSeq
        << config_.initial_conditions.wheel_speeds[0]
        << config_.initial_conditions.wheel_speeds[1]
        << config_.initial_conditions.wheel_speeds[2]
        << config_.initial_conditions.wheel_speeds[3] << YAML::EndSeq;
    out << YAML::EndMap;
    
    // Save to file
    std::ofstream fout(config_file);
    fout << out.c_str();
    fout.close();
    
    std::cout << "Configuration saved to " << config_file << std::endl;
}

// Helper functions for parsing
Eigen::Quaterniond ConfigManager::parse_quaternion(const YAML::Node& node) {
    if (node.size() == 4) {
        return Eigen::Quaterniond(
            node[0].as<double>(),
            node[1].as<double>(),
            node[2].as<double>(),
            node[3].as<double>()
        );
    }
    return Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
}

Eigen::Vector3d ConfigManager::parse_vector3d(const YAML::Node& node) {
    if (node.size() == 3) {
        return Eigen::Vector3d(
            node[0].as<double>(),
            node[1].as<double>(),
            node[2].as<double>()
        );
    }
    return Eigen::Vector3d::Zero();
}

Eigen::Vector4d ConfigManager::parse_vector4d(const YAML::Node& node) {
    if (node.size() == 4) {
        return Eigen::Vector4d(
            node[0].as<double>(),
            node[1].as<double>(),
            node[2].as<double>(),
            node[3].as<double>()
        );
    }
    return Eigen::Vector4d::Zero();
}

Eigen::Matrix3d ConfigManager::parse_matrix3d(const YAML::Node& node) {
    Eigen::Matrix3d mat = Eigen::Matrix3d::Zero();
    if (node.IsSequence() && node.size() == 9) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                mat(i, j) = node[i * 3 + j].as<double>();
            }
        }
    }
    return mat;
}

Eigen::Matrix<double, 6, 6> ConfigManager::parse_matrix6d(const YAML::Node& node) {
    Eigen::Matrix<double, 6, 6> mat = Eigen::Matrix<double, 6, 6>::Identity();
    if (node.IsSequence() && node.size() == 36) {
        for (int i = 0; i < 6; ++i) {
            for (int j = 0; j < 6; ++j) {
                mat(i, j) = node[i * 6 + j].as<double>();
            }
        }
    }
    return mat;
}

Eigen::Matrix<double, 3, 3> ConfigManager::parse_matrix3x3(const YAML::Node& node) {
    Eigen::Matrix<double, 3, 3> mat = Eigen::Matrix<double, 3, 3>::Identity();
    if (node.IsSequence() && node.size() == 9) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                mat(i, j) = node[i * 3 + j].as<double>();
            }
        }
    }
    return mat;
}

Eigen::Matrix<double, 3, 6> ConfigManager::parse_matrix3x6(const YAML::Node& node) {
    Eigen::Matrix<double, 3, 6> mat = Eigen::Matrix<double, 3, 6>::Zero();
    if (node.IsSequence() && node.size() == 18) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 6; ++j) {
                mat(i, j) = node[i * 6 + j].as<double>();
            }
        }
    }
    return mat;
}

Eigen::Matrix<double, 3, 4> ConfigManager::parse_matrix3x4(const YAML::Node& node) {
    Eigen::Matrix<double, 3, 4> mat = Eigen::Matrix<double, 3, 4>::Zero();
    if (node.IsSequence() && node.size() == 12) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 4; ++j) {
                mat(i, j) = node[i * 4 + j].as<double>();
            }
        }
    }
    return mat;
}