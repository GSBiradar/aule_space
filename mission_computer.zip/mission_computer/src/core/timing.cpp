#include "core/timing.h"
#include <thread>
#include <chrono>

HighResolutionTimer::HighResolutionTimer() : running_(false) {}

void HighResolutionTimer::start() {
    start_time_ = std::chrono::high_resolution_clock::now();
    running_ = true;
}

void HighResolutionTimer::stop() {
    if (running_) {
        end_time_ = std::chrono::high_resolution_clock::now();
        running_ = false;
    }
}

double HighResolutionTimer::elapsed_milliseconds() const {
    if (running_) {
        auto current = std::chrono::high_resolution_clock::now();
        return std::chrono::duration<double, std::milli>(current - start_time_).count();
    } else {
        return std::chrono::duration<double, std::milli>(end_time_ - start_time_).count();
    }
}

double HighResolutionTimer::elapsed_microseconds() const {
    if (running_) {
        auto current = std::chrono::high_resolution_clock::now();
        return std::chrono::duration<double, std::micro>(current - start_time_).count();
    } else {
        return std::chrono::duration<double, std::micro>(end_time_ - start_time_).count();
    }
}

double HighResolutionTimer::elapsed_seconds() const {
    return elapsed_milliseconds() / 1000.0;
}

RateLimiter::RateLimiter(double frequency_hz) {
    set_frequency(frequency_hz);
    next_time_ = std::chrono::high_resolution_clock::now();
}

void RateLimiter::sleep() {
    next_time_ += period_;
    std::this_thread::sleep_until(next_time_);
}

void RateLimiter::set_frequency(double frequency_hz) {
    period_ = std::chrono::duration<double>(1.0 / frequency_hz);
}

double RateLimiter::get_frequency() const {
    return 1.0 / period_.count();
}

SimulationClock::SimulationClock(double time_step) : time_step_(time_step) {}

void SimulationClock::increment() {
    current_time_ += time_step_;
    tick_count_++;
}

void SimulationClock::set_time(double time) {
    current_time_ = time;
}

double SimulationClock::get_time() const {
    return current_time_;
}

uint64_t SimulationClock::get_ticks() const {
    return tick_count_;
}

void SimulationClock::set_time_step(double time_step) {
    time_step_ = time_step;
}