#include "core/ipc.h"
#include <fstream>
#include <iostream>
#include <iomanip>

IPCManager::IPCManager() {
    attitude_state_queue_.set_max_size(10);
    sensor_data_queue_.set_max_size(10);
    control_command_queue_.set_max_size(10);
}

void IPCManager::publish_attitude_state(const AttitudeState& state) {
    if (attitude_state_queue_.push(state)) {
        std::lock_guard<std::mutex> lock(latest_mutex_);
        latest_attitude_state_ = state;
    }
}

void IPCManager::publish_sensor_data(const SensorData& data) {
    if (sensor_data_queue_.push(data)) {
        std::lock_guard<std::mutex> lock(latest_mutex_);
        latest_sensor_data_ = data;
    }
}

void IPCManager::publish_control_command(const ControlCommand& cmd) {
    if (control_command_queue_.push(cmd)) {
        std::lock_guard<std::mutex> lock(latest_mutex_);
        latest_control_command_ = cmd;
    }
}

bool IPCManager::get_latest_attitude_state(AttitudeState& state) {
    std::lock_guard<std::mutex> lock(latest_mutex_);
    state = latest_attitude_state_;
    return true;
}

bool IPCManager::get_latest_sensor_data(SensorData& data) {
    std::lock_guard<std::mutex> lock(latest_mutex_);
    data = latest_sensor_data_;
    return data.valid;
}

bool IPCManager::get_latest_control_command(ControlCommand& cmd) {
    std::lock_guard<std::mutex> lock(latest_mutex_);
    cmd = latest_control_command_;
    return true;
}

void IPCManager::log_state(const AttitudeState& state) {
    std::lock_guard<std::mutex> lock(log_mutex_);
    state_log_.push_back(state);
}

void IPCManager::log_control(const ControlCommand& cmd) {
    std::lock_guard<std::mutex> lock(log_mutex_);
    control_log_.push_back(cmd);
}

void IPCManager::save_logs_to_file(const std::string& filename) {
    std::lock_guard<std::mutex> lock(log_mutex_);
    
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open log file: " << filename << std::endl;
        return;
    }
    
    // Write header
    file << "timestamp,"
         << "q_w,q_x,q_y,q_z,"
         << "w_x,w_y,w_z,"
         << "wheel1_speed,wheel2_speed,wheel3_speed,wheel4_speed,"
         << "wheel1_torque,wheel2_torque,wheel3_torque,wheel4_torque,"
         << "cmd_torque_x,cmd_torque_y,cmd_torque_z\n";
    
    // Write data
    for (size_t i = 0; i < state_log_.size(); ++i) {
        const auto& state = state_log_[i];
        const auto& control = (i < control_log_.size()) ? control_log_[i] : ControlCommand();
        
        file << std::fixed << std::setprecision(9)
             << state.timestamp << ","
             << state.attitude.w() << ","
             << state.attitude.x() << ","
             << state.attitude.y() << ","
             << state.attitude.z() << ","
             << state.angular_velocity.x() << ","
             << state.angular_velocity.y() << ","
             << state.angular_velocity.z() << ","
             << state.wheel_speeds[0] << ","
             << state.wheel_speeds[1] << ","
             << state.wheel_speeds[2] << ","
             << state.wheel_speeds[3] << ","
             << state.wheel_torques[0] << ","
             << state.wheel_torques[1] << ","
             << state.wheel_torques[2] << ","
             << state.wheel_torques[3] << ","
             << control.torque_body.x() << ","
             << control.torque_body.y() << ","
             << control.torque_body.z() << "\n";
    }
    
    file.close();
    std::cout << "Saved " << state_log_.size() << " log entries to " << filename << std::endl;
}