#include "core/scheduler.h"
#include <iostream>
#include <algorithm>
#include <chrono>

Scheduler::Scheduler() : ipc_manager_(nullptr) {
    // Initialize with nullptr, will be set by main
}

Scheduler::~Scheduler() {
    stop();
}

void Scheduler::initialize() {
    // Sort tasks by period (shortest period first)
    std::sort(tasks_.begin(), tasks_.end(),
              [](const TaskConfig& a, const TaskConfig& b) {
                  return a.period_ms < b.period_ms;
              });
    
    // Assign IDs
    for (size_t i = 0; i < tasks_.size(); ++i) {
        tasks_[i].id = static_cast<int>(i);
        tasks_[i].next_execution_time = 0;
    }
}

void Scheduler::add_task(const std::string& name, int period_ms,
                        std::function<void()> task, int priority) {
    TaskConfig config;
    config.name = name;
    config.period_ms = period_ms;
    config.task_function = task;
    config.priority = priority;
    config.next_execution_time = 0;
    
    tasks_.push_back(config);
    std::cout << "Added task: " << name << " (period: " << period_ms << "ms)" << std::endl;
}

void Scheduler::start() {
    if (running_) {
        return;
    }
    
    running_ = true;
    scheduler_thread_ = std::thread(&Scheduler::scheduler_thread, this);
}

void Scheduler::stop() {
    running_ = false;
    if (scheduler_thread_.joinable()) {
        scheduler_thread_.join();
    }
}

void Scheduler::run_simulation(double duration_seconds) {
    start();
    
    auto start_time = std::chrono::high_resolution_clock::now();
    double elapsed = 0.0;
    
    while (running_ && elapsed < duration_seconds) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        
        auto current_time = std::chrono::high_resolution_clock::now();
        elapsed = std::chrono::duration<double>(current_time - start_time).count();
        
        simulation_time_ = elapsed;
        simulation_ticks_++;
    }
    
    stop();
}

void Scheduler::scheduler_thread() {
    auto start_time = std::chrono::high_resolution_clock::now();
    uint64_t start_us = std::chrono::duration_cast<std::chrono::microseconds>(
        start_time.time_since_epoch()).count();
    
    // Initialize next execution times
    for (auto& task : tasks_) {
        task.next_execution_time = start_us;
    }
    
    while (running_) {
        auto current_time = std::chrono::high_resolution_clock::now();
        uint64_t current_us = std::chrono::duration_cast<std::chrono::microseconds>(
            current_time.time_since_epoch()).count();
        
        // Check and execute tasks
        for (auto& task : tasks_) {
            if (current_us >= task.next_execution_time) {
                execute_task(task);
                task.next_execution_time = current_us + (task.period_ms * 1000);
            }
        }
        
        // Sleep to prevent busy waiting
        std::this_thread::sleep_for(std::chrono::microseconds(100));
    }
}

void Scheduler::execute_task(TaskConfig& task) {
    try {
        task.task_function();
    } catch (const std::exception& e) {
        std::cerr << "Error executing task " << task.name << ": " << e.what() << std::endl;
    }
}

double Scheduler::get_simulation_time() const {
    return simulation_time_;
}