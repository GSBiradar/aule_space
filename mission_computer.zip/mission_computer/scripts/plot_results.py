import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
matplotlib.use('TkAgg')  # or 'Qt5Agg' depending on your system

def plot_simulation_results(log_file="simulation_log.csv"):
    # Load data
    data = pd.read_csv(log_file)
    
    # Convert timestamps to seconds
    data['time'] = data['timestamp'] * 1e-6
    
    # Create figure with subplots
    fig = plt.figure(figsize=(15, 10))
    
    # 1. Attitude (quaternion components)
    ax1 = plt.subplot(3, 3, 1)
    ax1.plot(data['time'], data['q_w'], label='q_w')
    ax1.plot(data['time'], data['q_x'], label='q_x')
    ax1.plot(data['time'], data['q_y'], label='q_y')
    ax1.plot(data['time'], data['q_z'], label='q_z')
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Quaternion')
    ax1.set_title('Attitude (Quaternion)')
    ax1.legend()
    ax1.grid(True)
    
    # 2. Angular velocity
    ax2 = plt.subplot(3, 3, 2)
    ax2.plot(data['time'], data['w_x'] * 180/np.pi, label='ω_x')
    ax2.plot(data['time'], data['w_y'] * 180/np.pi, label='ω_y')
    ax2.plot(data['time'], data['w_z'] * 180/np.pi, label='ω_z')
    ax2.set_xlabel('Time (s)')
    ax2.set_ylabel('Angular Velocity (deg/s)')
    ax2.set_title('Angular Velocity')
    ax2.legend()
    ax2.grid(True)
    
    # 3. Wheel speeds
    ax3 = plt.subplot(3, 3, 3)
    ax3.plot(data['time'], data['wheel1_speed'] * 30/np.pi, label='Wheel 1')
    ax3.plot(data['time'], data['wheel2_speed'] * 30/np.pi, label='Wheel 2')
    ax3.plot(data['time'], data['wheel3_speed'] * 30/np.pi, label='Wheel 3')
    ax3.plot(data['time'], data['wheel4_speed'] * 30/np.pi, label='Wheel 4')
    ax3.set_xlabel('Time (s)')
    ax3.set_ylabel('Speed (RPM)')
    ax3.set_title('Reaction Wheel Speeds')
    ax3.legend()
    ax3.grid(True)
    
    # 4. Control torques
    ax4 = plt.subplot(3, 3, 4)
    ax4.plot(data['time'], data['cmd_torque_x'], label='τ_x')
    ax4.plot(data['time'], data['cmd_torque_y'], label='τ_y')
    ax4.plot(data['time'], data['cmd_torque_z'], label='τ_z')
    ax4.set_xlabel('Time (s)')
    ax4.set_ylabel('Torque (N·m)')
    ax4.set_title('Control Torques')
    ax4.legend()
    ax4.grid(True)
    
    # 5. Wheel torques
    ax5 = plt.subplot(3, 3, 5)
    ax5.plot(data['time'], data['wheel1_torque'], label='Wheel 1')
    ax5.plot(data['time'], data['wheel2_torque'], label='Wheel 2')
    ax5.plot(data['time'], data['wheel3_torque'], label='Wheel 3')
    ax5.plot(data['time'], data['wheel4_torque'], label='Wheel 4')
    ax5.set_xlabel('Time (s)')
    ax5.set_ylabel('Torque (N·m)')
    ax5.set_title('Wheel Torques')
    ax5.legend()
    ax5.grid(True)
    
    # 6. Quaternion error (distance from identity)
    ax6 = plt.subplot(3, 3, 6)
    q_norm = np.sqrt(data['q_w']**2 + data['q_x']**2 + data['q_y']**2 + data['q_z']**2)
    ax6.plot(data['time'], q_norm)
    ax6.set_xlabel('Time (s)')
    ax6.set_ylabel('Quaternion Norm')
    ax6.set_title('Quaternion Norm (should be ~1)')
    ax6.grid(True)
    
    # 7. Euler angles (approximate)
    ax7 = plt.subplot(3, 3, 7)
    # Convert quaternion to Euler angles (roll, pitch, yaw)
    # Note: This is a simplified conversion
    w, x, y, z = data['q_w'], data['q_x'], data['q_y'], data['q_z']
    
    # Roll (x-axis rotation)
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x * x + y * y)
    roll = np.arctan2(sinr_cosp, cosr_cosp)
    
    # Pitch (y-axis rotation)
    sinp = 2 * (w * y - z * x)
    pitch = np.where(np.abs(sinp) >= 1, 
                     np.copysign(np.pi/2, sinp),
                     np.arcsin(sinp))
    
    # Yaw (z-axis rotation)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = np.arctan2(siny_cosp, cosy_cosp)
    
    ax7.plot(data['time'], roll * 180/np.pi, label='Roll')
    ax7.plot(data['time'], pitch * 180/np.pi, label='Pitch')
    ax7.plot(data['time'], yaw * 180/np.pi, label='Yaw')
    ax7.set_xlabel('Time (s)')
    ax7.set_ylabel('Angle (deg)')
    ax7.set_title('Euler Angles')
    ax7.legend()
    ax7.grid(True)
    
    # 8. Total angular momentum
    ax8 = plt.subplot(3, 3, 8)
    # Approximate angular momentum: L = I * ω
    I_xx, I_yy, I_zz = 10.0, 10.0, 5.0  # From config
    L_x = I_xx * data['w_x']
    L_y = I_yy * data['w_y']
    L_z = I_zz * data['w_z']
    L_total = np.sqrt(L_x**2 + L_y**2 + L_z**2)
    
    ax8.plot(data['time'], L_total)
    ax8.set_xlabel('Time (s)')
    ax8.set_ylabel('Angular Momentum (kg·m²/s)')
    ax8.set_title('Total Angular Momentum')
    ax8.grid(True)
    
    # 9. 3D attitude visualization
    ax9 = plt.subplot(3, 3, 9, projection='3d')
    
    # Sample points for body axes
    sample_step = len(data) // 20  # Sample 20 points
    sample_indices = range(0, len(data), sample_step)
    
    for idx in sample_indices:
        q = [data['q_w'].iloc[idx], 
             data['q_x'].iloc[idx],
             data['q_y'].iloc[idx],
             data['q_z'].iloc[idx]]
        
        # Rotate body axes by quaternion
        body_x = np.array([1, 0, 0])
        body_y = np.array([0, 1, 0])
        body_z = np.array([0, 0, 1])
        
        # Convert quaternion to rotation matrix (simplified)
        w, x, y, z = q
        R = np.array([
            [1 - 2*y*y - 2*z*z, 2*x*y - 2*z*w, 2*x*z + 2*y*w],
            [2*x*y + 2*z*w, 1 - 2*x*x - 2*z*z, 2*y*z - 2*x*w],
            [2*x*z - 2*y*w, 2*y*z + 2*x*w, 1 - 2*x*x - 2*y*y]
        ])
        
        rotated_x = R @ body_x
        rotated_y = R @ body_y
        rotated_z = R @ body_z
        
        # Plot axes
        time_scaled = data['time'].iloc[idx] / data['time'].max()
        color = plt.cm.viridis(time_scaled)
        
        ax9.quiver(0, 0, 0, rotated_x[0], rotated_x[1], rotated_x[2], 
                  color='r', alpha=0.5, length=0.5)
        ax9.quiver(0, 0, 0, rotated_y[0], rotated_y[1], rotated_y[2], 
                  color='g', alpha=0.5, length=0.5)
        ax9.quiver(0, 0, 0, rotated_z[0], rotated_z[1], rotated_z[2], 
                  color='b', alpha=0.5, length=0.5)
    
    ax9.set_xlim([-1, 1])
    ax9.set_ylim([-1, 1])
    ax9.set_zlim([-1, 1])
    ax9.set_xlabel('X')
    ax9.set_ylabel('Y')
    ax9.set_zlabel('Z')
    ax9.set_title('Attitude Evolution (Sampled)')
    
    plt.tight_layout()
    plt.savefig('simulation_results.png', dpi=300, bbox_inches='tight')
    plt.show()

def compare_with_simulink(cpp_log, simulink_log):
    """
    Compare C++ simulation results with Simulink output
    """
    cpp_data = pd.read_csv(cpp_log)
    simulink_data = pd.read_csv(simulink_log)
    
    # Ensure same time scale
    cpp_time = cpp_data['timestamp'] * 1e-6
    simulink_time = simulink_data['Time']
    
    # Interpolate to common time points
    common_time = np.linspace(max(cpp_time.min(), simulink_time.min()),
                             min(cpp_time.max(), simulink_time.max()),
                             1000)
    
    fig, axes = plt.subplots(3, 2, figsize=(12, 10))
    
    # Compare quaternions
    for i, q_comp in enumerate(['q_w', 'q_x', 'q_y', 'q_z']):
        if q_comp in cpp_data.columns and f'Quaternion_{i+1}' in simulink_data.columns:
            ax = axes[i//2, i%2]
            
            # Interpolate
            cpp_q = np.interp(common_time, cpp_time, cpp_data[q_comp])
            simulink_q = np.interp(common_time, simulink_time, 
                                  simulink_data[f'Quaternion_{i+1}'])
            
            ax.plot(common_time, cpp_q, 'b-', label='C++', alpha=0.7)
            ax.plot(common_time, simulink_q, 'r--', label='Simulink', alpha=0.7)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel(f'{q_comp}')
            ax.set_title(f'Quaternion Component {i+1}')
            ax.legend()
            ax.grid(True)
            
            # Calculate error
            error = np.abs(cpp_q - simulink_q)
            print(f"Mean error for {q_comp}: {error.mean():.6f}")
            print(f"Max error for {q_comp}: {error.max():.6f}")
    
    plt.tight_layout()
    plt.savefig('comparison_results.png', dpi=300)
    plt.show()

if __name__ == "__main__":
    plot_simulation_results("simulation_log.csv")
    
    # If you have Simulink data:
    # compare_with_simulink("simulation_log.csv", "simulink_output.csv")