#ifndef CONFIG_MANAGER_H
#define CONFIG_MANAGER_H

#include <string>
#include <yaml-cpp/yaml.h>
#include "modules/controller.h"
#include "modules/dynamics.h"
#include "modules/actuator.h"
#include "modules/sensor.h"

struct SimulationConfig {
    struct InitialConditions {
        Eigen::Quaterniond attitude;
        Eigen::Vector3d angular_velocity;
        Eigen::Vector4d wheel_speeds;
    };
    
    struct SimulationParams {
        double duration;        // seconds
        double time_step;       // seconds
        bool real_time;
        double real_time_factor;
        std::string log_file;
    };
    
    InitialConditions initial_conditions;
    SimulationParams simulation_params;
    LQRController::Config controller_config;
    SpacecraftDynamics::Config dynamics_config;
    ReactionWheelActuator::Config actuator_config;
    AttitudeSensor::Config sensor_config;
};

class ConfigManager {
public:
    ConfigManager();
    
    bool load_config(const std::string& config_file);
    const SimulationConfig& get_config() const;
    
    void save_config(const std::string& config_file) const;
    void set_default_config();
    
private:
    SimulationConfig config_;
    
    Eigen::Quaterniond parse_quaternion(const YAML::Node& node);
    Eigen::Vector3d parse_vector3d(const YAML::Node& node);
    Eigen::Vector4d parse_vector4d(const YAML::Node& node);
    Eigen::Matrix3d parse_matrix3d(const YAML::Node& node);
    Eigen::Matrix<double, 6, 6> parse_matrix6d(const YAML::Node& node);
    Eigen::Matrix<double, 3, 3> parse_matrix3x3(const YAML::Node& node);
    Eigen::Matrix<double, 3, 6> parse_matrix3x6(const YAML::Node& node);
    Eigen::Matrix<double, 3, 4> parse_matrix3x4(const YAML::Node& node);
};

#endif // CONFIG_MANAGER_H