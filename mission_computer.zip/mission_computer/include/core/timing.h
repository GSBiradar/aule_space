#ifndef TIMING_H
#define TIMING_H

#include <chrono>
#include <cstdint>

class HighResolutionTimer {
public:
    HighResolutionTimer();
    
    void start();
    void stop();
    double elapsed_milliseconds() const;
    double elapsed_microseconds() const;
    double elapsed_seconds() const;
    
private:
    std::chrono::high_resolution_clock::time_point start_time_;
    std::chrono::high_resolution_clock::time_point end_time_;
    bool running_{false};
};

class RateLimiter {
public:
    RateLimiter(double frequency_hz);
    
    void sleep();
    void set_frequency(double frequency_hz);
    double get_frequency() const;
    
private:
    std::chrono::duration<double> period_;
    std::chrono::high_resolution_clock::time_point next_time_;
};

class SimulationClock {
public:
    SimulationClock(double time_step = 0.001);
    
    void increment();
    void set_time(double time);
    double get_time() const;
    uint64_t get_ticks() const;
    void set_time_step(double time_step);
    
private:
    double current_time_{0.0};
    double time_step_{0.001};
    uint64_t tick_count_{0};
};

#endif // TIMING_H