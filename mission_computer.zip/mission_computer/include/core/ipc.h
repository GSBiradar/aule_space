#ifndef IPC_H
#define IPC_H

#include <queue>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <memory>
#include <Eigen/Dense>
#include <Eigen/Geometry>

struct AttitudeState {
    Eigen::Quaterniond attitude;          // w, x, y, z
    Eigen::Vector3d angular_velocity;     // rad/s
    Eigen::Vector4d wheel_speeds;         // rad/s
    Eigen::Vector4d wheel_torques;        // N·m
    uint64_t timestamp;
    
    AttitudeState() : 
        attitude(1.0, 0.0, 0.0, 0.0),
        angular_velocity(Eigen::Vector3d::Zero()),
        wheel_speeds(Eigen::Vector4d::Zero()),
        wheel_torques(Eigen::Vector4d::Zero()),
        timestamp(0) {}
};

struct SensorData {
    Eigen::Quaterniond measured_attitude;
    Eigen::Vector3d measured_rates;
    Eigen::Vector4d measured_wheel_speeds;
    uint64_t timestamp;
    bool valid;
    
    SensorData() : 
        measured_attitude(1.0, 0.0, 0.0, 0.0),
        measured_rates(Eigen::Vector3d::Zero()),
        measured_wheel_speeds(Eigen::Vector4d::Zero()),
        timestamp(0),
        valid(false) {}
};

struct ControlCommand {
    Eigen::Vector3d torque_body;          // Commanded torque in body frame
    Eigen::Vector4d wheel_torques;        // Individual wheel torques
    uint64_t timestamp;
    
    ControlCommand() : 
        torque_body(Eigen::Vector3d::Zero()),
        wheel_torques(Eigen::Vector4d::Zero()),
        timestamp(0) {}
};

template<typename T>
class ThreadSafeQueue {
private:
    std::queue<T> queue_;
    mutable std::mutex mutex_;
    std::condition_variable cond_;
    size_t max_size_{1000};
    
public:
    ThreadSafeQueue() = default;
    
    bool push(const T& item) {
        std::unique_lock<std::mutex> lock(mutex_);
        if (queue_.size() >= max_size_) {
            return false;  // Queue full
        }
        queue_.push(item);
        lock.unlock();
        cond_.notify_one();
        return true;
    }
    
    bool pop(T& item) {
        std::unique_lock<std::mutex> lock(mutex_);
        if (queue_.empty()) {
            return false;
        }
        item = queue_.front();
        queue_.pop();
        return true;
    }
    
    bool empty() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.empty();
    }
    
    size_t size() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.size();
    }
    
    void set_max_size(size_t max_size) {
        std::lock_guard<std::mutex> lock(mutex_);
        max_size_ = max_size;
    }
};

class IPCManager {
public:
    IPCManager();
    
    // State publishing
    void publish_attitude_state(const AttitudeState& state);
    void publish_sensor_data(const SensorData& data);
    void publish_control_command(const ControlCommand& cmd);
    
    // State retrieval
    bool get_latest_attitude_state(AttitudeState& state);
    bool get_latest_sensor_data(SensorData& data);
    bool get_latest_control_command(ControlCommand& cmd);
    
    // Data logging
    void log_state(const AttitudeState& state);
    void log_control(const ControlCommand& cmd);
    void save_logs_to_file(const std::string& filename);
    
private:
    ThreadSafeQueue<AttitudeState> attitude_state_queue_;
    ThreadSafeQueue<SensorData> sensor_data_queue_;
    ThreadSafeQueue<ControlCommand> control_command_queue_;
    
    std::vector<AttitudeState> state_log_;
    std::vector<ControlCommand> control_log_;
    std::mutex log_mutex_;
    
    AttitudeState latest_attitude_state_;
    SensorData latest_sensor_data_;
    ControlCommand latest_control_command_;
    std::mutex latest_mutex_;
};

#endif // IPC_H