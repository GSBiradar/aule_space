#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <functional>
#include <map>
#include <vector>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <thread>
#include "ipc.h"
#include "timing.h"

class Scheduler {
public:
    struct TaskConfig {
        int id;
        std::string name;
        int period_ms;
        int priority;
        std::function<void()> task_function;
        uint64_t next_execution_time;
    };

    Scheduler();
    ~Scheduler();

    void initialize();
    void add_task(const std::string& name, int period_ms, 
                  std::function<void()> task, int priority = 0);
    void start();
    void stop();
    void run_simulation(double duration_seconds);
    double get_simulation_time() const;
    
private:
    void scheduler_thread();
    void execute_task(TaskConfig& task);
    
    std::vector<TaskConfig> tasks_;
    std::thread scheduler_thread_;
    std::atomic<bool> running_{false};
    std::mutex mutex_;
    std::condition_variable cv_;
    
    double simulation_time_{0.0};
    double time_scale_{1.0};  // For real-time scaling if needed
    uint64_t simulation_ticks_{0};
    
    IPCManager* ipc_manager_;
};

#endif // SCHEDULER_H