#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <Eigen/Dense>
#include <Eigen/Geometry>
#include "core/ipc.h"

class LQRController {
public:
    struct Config {
        Eigen::Matrix<double, 6, 6> Q;  // State cost matrix
        Eigen::Matrix<double, 3, 3> R;  // Control cost matrix
        Eigen::Matrix<double, 3, 6> K;  // LQR gain matrix
        double max_torque;               // N·m
        double integral_gain;           // For integral action if needed
    };
    
    LQRController();
    
    void initialize(const Config& config);
    ControlCommand compute_control(const Eigen::Quaterniond& q_ref,
                                  const SensorData& sensor_data,
                                  const AttitudeState& state);
    
    void set_reference_attitude(const Eigen::Quaterniond& q_ref);
    Eigen::Vector3d compute_quaternion_error(const Eigen::Quaterniond& q_ref,
                                            const Eigen::Quaterniond& q_est);
    
    bool compute_lqr_gain(const Eigen::Matrix<double, 6, 6>& A,
                         const Eigen::Matrix<double, 6, 3>& B,
                         const Eigen::Matrix<double, 6, 6>& Q,
                         const Eigen::Matrix<double, 3, 3>& R);
    
private:
    Config config_;
    Eigen::Quaterniond reference_attitude_;
    Eigen::Vector3d integral_error_;
    
    Eigen::Vector4d torque_allocation(const Eigen::Vector3d& torque_body);
};

#endif // CONTROLLER_H