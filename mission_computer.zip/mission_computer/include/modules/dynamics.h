#ifndef DYNAMICS_H
#define DYNAMICS_H

#include <Eigen/Dense>
#include <Eigen/Geometry>
#include "core/ipc.h"

class SpacecraftDynamics {
public:
    struct Config {
        double mass;                    // kg
        Eigen::Matrix3d inertia;        // kg·m²
        Eigen::Matrix3d inertia_inv;    // Inverse inertia
        Eigen::Matrix<double, 3, 4> wheel_matrix;  // Wheel configuration
        double wheel_inertia;           // Individual wheel inertia
        double max_wheel_speed;         // rad/s
        double max_wheel_torque;        // N·m
    };
    
    SpacecraftDynamics();
    
    void initialize(const Config& config);
    void update(double dt, const ControlCommand& cmd, AttitudeState& state);
    
    Eigen::Matrix3d compute_skew_symmetric(const Eigen::Vector3d& v);
    void quaternion_derivative(Eigen::Quaterniond& q, 
                               const Eigen::Vector3d& omega);
    
private:
    Config config_;
    
    Eigen::Vector3d compute_total_torque(const ControlCommand& cmd,
                                        const AttitudeState& state);
    void update_attitude(double dt, AttitudeState& state);
    void update_angular_velocity(double dt, const Eigen::Vector3d& torque,
                                AttitudeState& state);
    void update_reaction_wheels(double dt, const ControlCommand& cmd,
                               AttitudeState& state);
};

#endif // DYNAMICS_H