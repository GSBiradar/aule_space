#ifndef SENSOR_H
#define SENSOR_H

#include <random>
#include <Eigen/Dense>
#include <Eigen/Geometry>
#include "core/ipc.h"

class AttitudeSensor {
public:
    struct Config {
        double attitude_noise_std;      // radians
        double rate_noise_std;          // rad/s
        double wheel_speed_noise_std;   // rad/s
        double update_rate_hz;
        double latency;                 // seconds
        bool enable_noise;
    };
    
    AttitudeSensor();
    
    void initialize(const Config& config);
    SensorData generate_measurement(const AttitudeState& true_state,
                                   uint64_t timestamp);
    
    Eigen::Quaterniond add_attitude_noise(const Eigen::Quaterniond& true_attitude);
    Eigen::Vector3d add_rate_noise(const Eigen::Vector3d& true_rates);
    Eigen::Vector4d add_wheel_noise(const Eigen::Vector4d& true_speeds);
    
private:
    Config config_;
    std::default_random_engine random_engine_;
    std::normal_distribution<double> normal_dist_;
    
    double last_update_time_{0.0};
    
    Eigen::Quaterniond random_quaternion();
};

#endif // SENSOR_H