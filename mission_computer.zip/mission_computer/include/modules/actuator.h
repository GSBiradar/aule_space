#ifndef ACTUATOR_H
#define ACTUATOR_H

#include <Eigen/Dense>
#include "core/ipc.h"

class ReactionWheelActuator {
public:
    struct Config {
        double max_torque;          // N·m
        double max_speed;           // rad/s
        double friction_coefficient;
        double motor_constant;
        double resistance;
        double time_constant;       // First-order lag
        Eigen::Matrix<double, 3, 4> allocation_matrix;
    };
    
    ReactionWheelActuator();
    
    void initialize(const Config& config);
    Eigen::Vector4d compute_wheel_torques(const Eigen::Vector3d& torque_body);
    void apply_saturation(Eigen::Vector4d& wheel_torques,
                         Eigen::Vector4d& wheel_speeds);
    void update_dynamics(double dt, Eigen::Vector4d& wheel_torques,
                        Eigen::Vector4d& wheel_speeds);
    
private:
    Config config_;
    Eigen::Vector4d previous_torques_;
    
    Eigen::Vector4d compute_motor_currents(const Eigen::Vector4d& desired_torques);
    Eigen::Vector4d compute_electrical_dynamics(double dt,
                                               const Eigen::Vector4d& currents);
    Eigen::Vector4d compute_mechanical_dynamics(double dt,
                                               const Eigen::Vector4d& torques,
                                               Eigen::Vector4d& speeds);
};

#endif // ACTUATOR_H